
<a><img src='https://i.imgur.com/NO0Ko4G.jpeg'/></a>

-------

 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=00008B&center=true&vCenter=true&multiline=false&lines=`CRAZY+-+MD+-+V1+WHATSAPP+BOT`" alt="">

<br>
<p>𝐂𝐇𝐔𝐃𝐃𝐘 𝐁𝐔𝐃𝐃𝐘 𝐖𝐇𝐀𝐓𝐒𝐀𝐏𝐏 𝐁𝐎𝐓 𝐌𝐀𝐊𝐄 𝐅𝐎𝐑 𝐄𝐃𝐔𝐂𝐀𝐓𝐈𝐎𝐍𝐀𝐋 𝐏𝐔𝐑𝐏𝐎𝐒𝐄🍒</p>

--------
<div align="center"><br> <img src="https://profile-counter.glitch.me/CRAZY-MD-V1/count.svg" /><br>CRAZY-MD-V1</div>

------------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

[![FORK CRAZY_MD-V1](https://img.shields.io/badge/FORK%20-CRAZY%20MD%20V1-white)](https://github.com/LORD-IGWE/CRAZY-MD-V1/fork)

### <br>    ❖ SESSION_ID ❖


`✠ IF YOU DON'T HAVE YOUR SESSION_ID SO U CAN GET IT CLICK ON SESSION_ID BUTTON AND PASTE YOUR NUMBER With COUNTRY CODE EXAMPLE:+241xxxxxx THEN YOU CAN GET YOUR SESSION_ID ✠`

----------
1. USE SESSION 1.
<p align="center">
<a href="https://igwe-api-key.onrender.com/"><img height= "35" title="Author" src="https://img.shields.io/badge/GET SESSION ID:1-black?style=for-the-badge&logo=render"></a>
<p/>
 
### <br>   ❖ DEPLOY_HEROKU ❖

`✠ IF YOU WANT TO DEPLOY KERM MD V1 BOT ON HEROKU SO FIRST GET YOUR SESSION_ID THEN CLICK THIS BLUE BUTTON [DEPLOY TO HEROKU] THEN YOU CAN ENJOY THIS BOT ✠`

------------
 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new-app?template=https://github.com/Kgtech-cmr/KERM-MD-V1)

----------

### <br>    ❖ DEPLOY_TALKDROVE ❖

  1. Deploy Now. 

<a href='https://host.talkdrove.com/dashboard/select-bot/prepare-deployment?botId=51' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY-NOW-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

----------

### <br>    ❖ DEPLOY_REPLIT ❖

`✠ IF U HAVE YOUR REPLIT ACCOUNT SO YOU CAN EASY DEPLOY KERM MD V4 ON REPLIT CLICK BLACK BUTTON [DEPLOY TO REPLIT] AND FIND CONFIG.JSON FILE THEN PASTE YOUR SESSION AND MONGODB KEY THEN RUN CODE AND ENJOY BOT ✠`

-------------

<p align="left"><a href="https://repl.it/github/Kgtech-cmr/KERM-MD-V1"> <img src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------------

### <br>   ❖ DEPLOY_KOYEB ❖

`✠ IF YOU HAVE YOUR KOYEB ACCOUNT SO YOU CAN DEPLOY KERM MD V1 ON KOYEB WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON ✠`

---------

<a href='https://app.koyeb.com/auth/signin' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-KOYEB-blue?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

------------

### <br>  ❖ DEPLOY_RAILWAY ❖

`✠ IF YOU HAVE YOUR RAILWAY ACCOUNT SO YOU CAN DEPLOY KERM MD V1 ON RAILWAY WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON ✠`

--------

<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RAILWAY-h?color=black&style=for-the-badge&logo=railway'/></a></p>

---------------

### <br> ❖ MORE DEPLOY METHOD ❖

--------
### <br>   ❖ DEPLOY_GLITCH ❖

<a href='https://glitch.com/signup' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/GLITCH-h?color=pink&style=for-the-badge&logo=glitch'/></a></p>

--------

### <br>   ❖ DEPLOY_CODESPACE ❖

<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/CODESPACE-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

--------

### <br>   ❖ DEPLOY_RENDER ❖

<a href='https://dashboard.render.com' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/RENDER-h?color=maroon&style=for-the-badge&logo=render'/></a></p>

-----------
